import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useRouter } from '../context/RouterContext';

export function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { signIn } = useAuth();
  const { navigate } = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    const result = await signIn(email, password);
    setLoading(false);
    if (result.error) setError(result.error);
    else navigate('dashboard');
  };

  return (
    <div className="min-h-screen flex" style={{ background: 'var(--bg-primary)' }}>
      {/* Left panel */}
      <div className="hidden lg:flex flex-col flex-1 relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #0f0f1a 0%, #1a1040 50%, #0d1a2e 100%)' }}>
        {/* Grid bg */}
        <div className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: 'linear-gradient(rgba(99,102,241,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(99,102,241,0.3) 1px, transparent 1px)',
            backgroundSize: '40px 40px'
          }} />
        {/* Glow */}
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full opacity-20 blur-3xl"
          style={{ background: 'radial-gradient(circle, #6366f1, transparent)' }} />

        <div className="relative z-10 flex flex-col justify-center flex-1 px-16 py-12">
          <div className="mb-12">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}>
                <span className="text-white font-bold">A</span>
              </div>
              <span className="text-white font-semibold text-xl">AprovaIA</span>
            </div>
            <h1 className="text-4xl font-bold text-white leading-tight mb-4">
              Sua aprovação<br />
              <span style={{ background: 'linear-gradient(135deg, #818cf8, #c084fc)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                começa aqui.
              </span>
            </h1>
            <p className="text-gray-400 text-lg leading-relaxed">
              Mentor inteligente que adapta o plano de estudos ao seu ritmo e maximiza suas chances de aprovação.
            </p>
          </div>

          {/* Features */}
          <div className="space-y-4">
            {[
              { icon: '🗺️', title: 'Mapa da Aprovação', desc: 'Visualize seu nível real e chance estimada de passar' },
              { icon: '🤖', title: 'Mentor IA Personalizado', desc: 'Tire dúvidas e receba orientação 24/7' },
              { icon: '📅', title: 'Cronograma Inteligente', desc: 'Plano semanal gerado com IA para seu concurso' },
            ].map((f, i) => (
              <div key={i} className="flex items-center gap-4 p-4 rounded-xl border border-white/[0.06]"
                style={{ background: 'rgba(255,255,255,0.03)' }}>
                <span className="text-2xl">{f.icon}</span>
                <div>
                  <p className="text-white font-medium text-sm">{f.title}</p>
                  <p className="text-gray-400 text-xs mt-0.5">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Social proof */}
          <div className="mt-12 flex items-center gap-4">
            <div className="flex -space-x-2">
              {['R','A','M','J','K'].map((l, i) => (
                <div key={i} className="w-8 h-8 rounded-full border-2 border-gray-900 flex items-center justify-center text-xs font-bold text-white"
                  style={{ background: ['#6366f1','#8b5cf6','#06b6d4','#10b981','#f59e0b'][i] }}>
                  {l}
                </div>
              ))}
            </div>
            <div>
              <p className="text-white text-sm font-medium">+2.400 aprovados</p>
              <p className="text-gray-400 text-xs">nos últimos 12 meses</p>
            </div>
          </div>
        </div>
      </div>

      {/* Right panel — form */}
      <div className="flex flex-col justify-center flex-1 max-w-md mx-auto px-8 py-12">
        {/* Mobile logo */}
        <div className="lg:hidden flex items-center gap-3 mb-10">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}>
            <span className="text-white font-bold">A</span>
          </div>
          <span className="text-white font-semibold text-lg">AprovaIA</span>
        </div>

        <h2 className="text-2xl font-bold text-white mb-1">Bem-vindo de volta</h2>
        <p className="text-gray-400 text-sm mb-8">Entre na sua conta para continuar estudando</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-gray-300 mb-1.5">Email</label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="seu@email.com"
              required
              className="w-full px-4 py-3 rounded-lg text-sm text-white placeholder-gray-500 border transition-all outline-none focus:border-indigo-500"
              style={{ background: 'rgba(255,255,255,0.05)', borderColor: 'rgba(255,255,255,0.1)' }}
            />
          </div>
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-gray-300">Senha</label>
              <button type="button" className="text-xs text-indigo-400 hover:text-indigo-300 transition-colors">
                Esqueceu a senha?
              </button>
            </div>
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              className="w-full px-4 py-3 rounded-lg text-sm text-white placeholder-gray-500 border transition-all outline-none focus:border-indigo-500"
              style={{ background: 'rgba(255,255,255,0.05)', borderColor: 'rgba(255,255,255,0.1)' }}
            />
          </div>

          {error && (
            <div className="px-4 py-3 rounded-lg border border-red-500/30 text-red-400 text-sm"
              style={{ background: 'rgba(239,68,68,0.08)' }}>
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-lg text-sm font-semibold text-white transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-60"
            style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Entrando...
              </span>
            ) : 'Entrar na plataforma'}
          </button>
        </form>

        <div className="mt-4 flex items-center gap-3">
          <div className="flex-1 h-px" style={{ background: 'rgba(255,255,255,0.08)' }} />
          <span className="text-gray-500 text-xs">ou</span>
          <div className="flex-1 h-px" style={{ background: 'rgba(255,255,255,0.08)' }} />
        </div>

        <p className="mt-6 text-center text-sm text-gray-400">
          Não tem conta?{' '}
          <button onClick={() => navigate('register')}
            className="text-indigo-400 hover:text-indigo-300 font-medium transition-colors">
            Criar conta grátis
          </button>
        </p>
      </div>
    </div>
  );
}
