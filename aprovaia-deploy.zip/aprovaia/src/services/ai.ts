const API_URL = 'https://api.anthropic.com/v1/messages';

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export async function sendMessage(
  messages: ChatMessage[],
  systemPrompt: string,
  onChunk?: (chunk: string) => void
): Promise<string> {
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 1000,
      system: systemPrompt,
      messages: messages.map(m => ({ role: m.role, content: m.content })),
      stream: false,
    }),
  });

  if (!response.ok) {
    // Fallback to mock responses for demo
    return getMockResponse(messages[messages.length - 1]?.content || '');
  }

  const data = await response.json();
  return data.content?.[0]?.text || getMockResponse(messages[messages.length - 1]?.content || '');
}

export async function generateSimulado(materia: string, quantidade: number = 5): Promise<string> {
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 1000,
      messages: [{
        role: 'user',
        content: `Gere ${quantidade} questões de múltipla escolha sobre ${materia} para concursos públicos brasileiros.
Responda APENAS com JSON válido, sem markdown, no formato:
{"questoes": [{"id": 1, "enunciado": "...", "alternativas": ["A) ...", "B) ...", "C) ...", "D) ...", "E) ..."], "gabarito": "A", "explicacao": "...", "materia": "${materia}", "dificuldade": "médio"}]}`
      }],
    }),
  });

  if (!response.ok) {
    return getMockSimulado(materia);
  }

  const data = await response.json();
  return data.content?.[0]?.text || getMockSimulado(materia);
}

export async function generateCronograma(params: {
  concurso: string;
  dataProva: string;
  horasDia: number;
  materiasDificeis: string[];
}): Promise<string> {
  const response = await fetch(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 1000,
      messages: [{
        role: 'user',
        content: `Crie um cronograma de estudos personalizado para:
Concurso: ${params.concurso}
Data da prova: ${params.dataProva}
Horas por dia disponíveis: ${params.horasDia}h
Matérias mais difíceis: ${params.materiasDificeis.join(', ')}

Responda APENAS com JSON válido, sem markdown:
{"semanas": [{"semana": 1, "foco": "...", "dias": [{"dia": "Segunda", "atividades": [{"materia": "...", "tipo": "estudo", "duracao": 60, "descricao": "..."}]}]}], "estrategia": "...", "dicas": ["..."]}`
      }],
    }),
  });

  if (!response.ok) {
    return getMockCronograma(params.concurso);
  }

  const data = await response.json();
  return data.content?.[0]?.text || getMockCronograma(params.concurso);
}

// ──────────── Mock fallbacks ────────────

function getMockResponse(input: string): string {
  const lower = input.toLowerCase();

  if (lower.includes('cronograma') || lower.includes('plano')) {
    return `## Plano de Estudos Personalizado 📚

Com base no seu perfil, recomendo a seguinte distribuição semanal:

**Segunda e Quarta:** Direito Constitucional (2h) + Direito Penal (1h)
**Terça e Quinta:** Direito Administrativo (2h) + Processo Penal (1h)
**Sexta:** Revisão geral + resolução de questões (2h)
**Sábado:** Simulado completo (3h)
**Domingo:** Descanso e revisão leve (1h)

### Dicas importantes:
- Use a técnica Pomodoro para manter o foco
- Priorize resolução de questões anteriores
- Faça revisões espaçadas a cada 7 dias
- Durma bem — consolida a memória

Quer que eu detalhe alguma matéria específica?`;
  }

  if (lower.includes('dica') || lower.includes('como estudar')) {
    return `## Estratégias de Alta Performance 🎯

**1. Lei de Pareto aplicada aos concursos**
80% das questões vêm de 20% do conteúdo. Identifique os temas mais cobrados na banca específica do seu concurso.

**2. Revisão espaçada**
Revise no dia seguinte, depois em 3 dias, 7 dias, 14 dias e 30 dias. Isso fixa o conteúdo na memória de longo prazo.

**3. Questões em quantidade**
Quem resolve mais questões passa. Meta mínima: 30 questões por dia, focadas nos temas do edital.

**4. Simulados cronometrados**
Simule as condições reais da prova semanalmente. Isso treina seu ritmo e gestão de tempo.

Qual aspecto você quer aprofundar?`;
  }

  if (lower.includes('redação') || lower.includes('dissertação')) {
    return `## Técnica de Redação para Concursos ✍️

**Estrutura obrigatória:**
- **Introdução** (3-4 linhas): apresente o tema e sua tese
- **Desenvolvimento I** (6-8 linhas): argumento principal com evidência
- **Desenvolvimento II** (6-8 linhas): argumento complementar
- **Conclusão** (3-4 linhas): retome a tese e proponha solução

**Checklist antes de entregar:**
✅ Paragrafação correta
✅ Ausência de gírias e coloquialismos
✅ Argumentos bem fundamentados
✅ Letra legível (escrita manual)
✅ Respeitou o limite de linhas

Quer que eu analise um texto seu ou sugira temas para treinar?`;
  }

  return `## Olá! Sou seu Mentor IA 🤖

Estou aqui para te ajudar a conquistar sua aprovação. Posso te auxiliar com:

📚 **Explicações de matérias** — Direito, Português, Matemática, Informática e mais
📋 **Cronograma personalizado** — plano semanal adaptado ao seu ritmo
📝 **Estratégias de estudo** — técnicas comprovadas para memorizar e revisar
🎯 **Análise de editais** — identificar o que realmente cai na prova
💡 **Dúvidas específicas** — qualquer tema do seu concurso

**Qual é o seu concurso alvo?** Me conte e vamos montar sua estratégia de aprovação!`;
}

function getMockSimulado(materia: string): string {
  return JSON.stringify({
    questoes: [
      {
        id: 1,
        enunciado: `Sobre ${materia}, é CORRETO afirmar que:`,
        alternativas: [
          'A) O princípio da legalidade estrita é absoluto no ordenamento jurídico.',
          'B) A Constituição Federal de 1988 adota o sistema presidencialista de governo.',
          'C) O controle difuso de constitucionalidade é exclusivo do STF.',
          'D) Os direitos fundamentais têm caráter meramente programático.',
          'E) A separação de poderes é cláusula pétrea relativa.'
        ],
        gabarito: 'B',
        explicacao: 'A Constituição Federal de 1988, em seu artigo 76, adota expressamente o sistema presidencialista, onde o Presidente da República é chefe de Estado e chefe de Governo simultaneamente. O controle difuso pode ser exercido por qualquer juízo, e os direitos fundamentais possuem aplicabilidade imediata conforme art. 5º §1º.',
        materia,
        dificuldade: 'médio'
      },
      {
        id: 2,
        enunciado: `Em relação aos princípios de ${materia}, assinale a alternativa INCORRETA:`,
        alternativas: [
          'A) O princípio da publicidade admite exceções previstas em lei.',
          'B) A moralidade administrativa é pressuposto de validade dos atos.',
          'C) A eficiência foi inserida pela Emenda Constitucional nº 19/1998.',
          'D) A impessoalidade proíbe qualquer tipo de tratamento diferenciado.',
          'E) A legalidade vincula toda a Administração Pública.'
        ],
        gabarito: 'D',
        explicacao: 'A impessoalidade não proíbe todo tratamento diferenciado, mas sim o favoritismo ou perseguição pessoal. Tratamentos diferenciados baseados em critérios objetivos e previstos em lei são permitidos, como ações afirmativas e cotas para deficientes.',
        materia,
        dificuldade: 'difícil'
      },
      {
        id: 3,
        enunciado: `Analise as seguintes afirmações sobre ${materia}:
I. A competência é elemento vinculado do ato administrativo.
II. O motivo e o objeto podem ser discricionários.
III. A forma é sempre livre na Administração Pública.`,
        alternativas: [
          'A) Apenas I está correta.',
          'B) Apenas I e II estão corretas.',
          'C) Apenas II e III estão corretas.',
          'D) Todas estão corretas.',
          'E) Nenhuma está correta.'
        ],
        gabarito: 'B',
        explicacao: 'A competência (I) é sempre vinculada — o agente deve ser competente por lei. O motivo e objeto (II) podem ser discricionários em atos onde a lei confere margem de escolha. A forma (III) não é livre — em regra deve ser escrita e motivada, salvo casos previstos em lei.',
        materia,
        dificuldade: 'difícil'
      },
      {
        id: 4,
        enunciado: `Segundo o entendimento consolidado sobre ${materia}, o prazo prescricional para ações civis contra a Fazenda Pública é de:`,
        alternativas: [
          'A) 1 ano',
          'B) 2 anos',
          'C) 5 anos',
          'D) 10 anos',
          'E) 20 anos'
        ],
        gabarito: 'C',
        explicacao: 'O Decreto nº 20.910/1932 estabelece o prazo de 5 anos para prescrição das dívidas passivas da União, Estados e Municípios. Este prazo é aplicado às ações civis em geral contra a Fazenda Pública, conforme entendimento consolidado nos tribunais.',
        materia,
        dificuldade: 'fácil'
      },
      {
        id: 5,
        enunciado: `Acerca do tema ${materia}, julgue o item: "O direito de petição pode ser exercido por pessoa jurídica."`,
        alternativas: [
          'A) Verdadeiro, pois pessoas jurídicas são titulares de todos os direitos fundamentais.',
          'B) Falso, pois o direito de petição é exclusivo de pessoas físicas.',
          'C) Verdadeiro, pois o art. 5º, XXXIV, não faz distinção entre pessoa física e jurídica.',
          'D) Falso, pois apenas cidadãos podem exercer tal direito.',
          'E) Verdadeiro, mas somente empresas públicas e sociedades de economia mista.'
        ],
        gabarito: 'C',
        explicacao: 'O direito de petição (art. 5º, XXXIV, "a") pode ser exercido por pessoa física ou jurídica, nacional ou estrangeira, pois a Constituição Federal não faz tal distinção. O STF já reconheceu esse entendimento em diversas oportunidades.',
        materia,
        dificuldade: 'médio'
      }
    ]
  });
}

function getMockCronograma(concurso: string): string {
  return JSON.stringify({
    semanas: [
      {
        semana: 1,
        foco: 'Base constitucional e revisão geral',
        dias: [
          { dia: 'Segunda', atividades: [{ materia: 'Direito Constitucional', tipo: 'estudo', duracao: 120, descricao: 'Princípios fundamentais e direitos individuais' }, { materia: 'Português', tipo: 'estudo', duracao: 60, descricao: 'Gramática e interpretação de texto' }] },
          { dia: 'Terça', atividades: [{ materia: 'Direito Administrativo', tipo: 'estudo', duracao: 120, descricao: 'Atos administrativos e poderes da administração' }, { materia: 'Questões', tipo: 'simulado', duracao: 60, descricao: '20 questões de Direito Constitucional' }] },
          { dia: 'Quarta', atividades: [{ materia: 'Direito Penal', tipo: 'estudo', duracao: 120, descricao: 'Teoria do crime e tipicidade' }, { materia: 'Revisão', tipo: 'revisao', duracao: 60, descricao: 'Revisão do conteúdo da semana' }] },
          { dia: 'Quinta', atividades: [{ materia: 'Processo Penal', tipo: 'estudo', duracao: 120, descricao: 'Inquérito policial e ação penal' }, { materia: 'Português', tipo: 'estudo', duracao: 60, descricao: 'Redação técnica' }] },
          { dia: 'Sexta', atividades: [{ materia: 'Revisão Geral', tipo: 'revisao', duracao: 120, descricao: 'Mapa mental de toda a semana' }, { materia: 'Questões', tipo: 'simulado', duracao: 60, descricao: '30 questões mistas' }] },
          { dia: 'Sábado', atividades: [{ materia: 'Simulado Completo', tipo: 'simulado', duracao: 180, descricao: 'Simulado com 40 questões no tempo real' }] },
          { dia: 'Domingo', atividades: [{ materia: 'Descanso', tipo: 'descanso', duracao: 60, descricao: 'Revisão leve e descanso mental' }] }
        ]
      }
    ],
    estrategia: `Para ${concurso}, foque em resolver o máximo de questões possível. A banca privilegia candidatos que dominam a jurisprudência atualizada e a letra da lei. Dedique 60% do tempo para resolução de questões e 40% para revisão de conteúdo.`,
    dicas: [
      'Priorize os temas com maior incidência histórica da banca',
      'Faça ao menos um simulado completo por semana',
      'Revise as questões erradas no dia seguinte',
      'Mantenha constância — estudar 3h todos os dias supera 8h no final de semana',
      'Cuide do sono e alimentação — isso impacta diretamente a memorização'
    ]
  });
}
